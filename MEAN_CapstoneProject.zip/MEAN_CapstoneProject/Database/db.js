const mongoose = require('mongoose');

// Define your MongoDB connection string
const connectionString = 'mongodb://127.0.0.1:27017/myDB2';

// Export the connection string
module.exports = connectionString;
