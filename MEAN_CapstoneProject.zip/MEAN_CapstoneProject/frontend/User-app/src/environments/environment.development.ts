export const environment = {
    production: false,
    backendApiUrl: 'http://localhost:3000'
  };