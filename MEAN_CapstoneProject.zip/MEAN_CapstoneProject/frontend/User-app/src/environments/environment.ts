export const environment = {
    production: true,
    backendApiUrl: 'http://3.81.9.237:3000'
  };